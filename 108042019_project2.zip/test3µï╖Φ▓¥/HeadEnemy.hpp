#ifndef HEADENEMY_HPP_INCLUDED
#define HEADENEMY_HPP_INCLUDED

#include "Enemy.hpp"

class HeadEnemy : public Enemy {
public:
	HeadEnemy(int x, int y);
};

#endif // HEADENEMY_HPP_INCLUDED
