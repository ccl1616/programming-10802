#include <string>
#include "HeadEnemy.hpp"

extern int test_enemy_speed_mul;
extern int slowdown_enemy;

HeadEnemy::HeadEnemy(int x, int y) : Enemy("play/enemy-4.png", x, y, 50, 30*test_enemy_speed_mul, 200, 200) {
	// TODO 2 (6/8): You can imitate the 2 files: 'SoldierEnemy.hpp', 'SoldierEnemy.cpp' to create a new enemy.
}
