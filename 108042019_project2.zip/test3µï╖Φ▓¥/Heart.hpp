#ifndef HEART_HPP_INCLUDED
#define HEART_HPP_INCLUDED


#include "Turret.hpp"

class Heart: public Turret {
public:
	static const int Price;
    Heart(float x, float y);
    void CreateBullet() override;
};



#endif // HEART_HPP_INCLUDED
