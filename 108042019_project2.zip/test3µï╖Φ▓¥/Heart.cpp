#include <allegro5/base.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
#include "Group.hpp"
#include "Heart.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"

const int Heart::Price = 350;
Heart::Heart(float x, float y) :
	Turret("play/tower-base.png", "play/turret-4.png", x, y, 1500, Price, 0.5) {
}
void Heart::CreateBullet() {
	Engine::Point diff = Engine::Point(cos(Rotation - ALLEGRO_PI / 2), sin(Rotation - ALLEGRO_PI / 2));

	// Change bullet position to the front of the gun barrel.

	//AudioHelper::PlayAudio("missile.wav");
}
